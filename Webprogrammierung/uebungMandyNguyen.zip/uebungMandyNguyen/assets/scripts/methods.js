{
  ("use strict");

  //returns live HTLM collection with all the matching tagnames
  const articles = document.getElementsByTagName("article");
  console.log(articles);
  console.log(articles[0].childNodes);

  //returns an HTML element object
  const intro = document.getElementById("intro");
  console.log(intro);
  console.log(intro.parentElement);
  console.log(intro.innerHTML);

  //returns a live HTML collection with all the elements with the matching classname
  const sections = document.getElementsByClassName("section");
  console.log(sections);

  //returns a live HTML collection
  const checkboxes = document.getElementsByName("license[]");

  //returns the first matching element as an element object
  const inputText = document.querySelector("[type=text]");
  console.log(inputText);

  //returns static NodeList
  const allRadio = document.querySelectorAll("[type=radio]");
  console.log(allRadio);

  let name = prompt("Wie ist dein Name?");

  alert(`Hallo ${name}!`);

  alert(`Und Tschüss ${name}!`);
}
